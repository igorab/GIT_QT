#include "sensor.h"

Sensor::Sensor()
{

}
